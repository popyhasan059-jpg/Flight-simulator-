# Skyline Flight Simulator 3D - Android project

A normal Android Studio / Gradle project (`app/src/main/...`). The game runs in a full-screen landscape WebView
from `app/src/main/assets/www/` and works fully offline (no internet permission, nothing collected).
The game source is `assets/www/index.html`; the 747-8i model is `assets/www/747-8i-model.js`; Three.js is in `assets/www/lib/`.

App id `com.skyline.flightsim` | minSdk 24 | compileSdk/targetSdk 36 (Google Play's requirement since 31 Aug 2026)
AGP 8.11.1 | Gradle 8.13 | JDK 17. Nothing here was compiled by the author - if a build error appears, send me the first red lines.

## Build the APK (pick one)

### A) In the cloud with GitHub Actions (no computer, no Android Studio)
1. Create a GitHub repo and put THIS folder's contents in it (keep `.github/workflows/build.yml`).
   Phone tip (Termux): `pkg install git`, unzip the project, then
   `git init && git add . && git commit -m init && git remote add origin <repo-url> && git push -u origin master`
2. Open the repo > Actions > "Build Android" > Run workflow. When it finishes, download the artifact
   `skyline-debug-apk`, unzip it and install the .apk on your phone to test.

### B) Android Studio (computer)
Open the folder, wait for Gradle sync, then Build > Build APK(s), or Build > Generate Signed App Bundle.

### C) Command line
`./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`

## Release for the Play Store (needs a signed .aab)
1. Make an upload key once (Termux: `pkg install openjdk-17`):
   `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   Keep `upload.jks` and its passwords safe and never upload them anywhere public.
2. GitHub repo > Settings > Secrets and variables > Actions, add:
   `KEYSTORE_BASE64` (output of `base64 -w0 upload.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (upload), `KEY_PASSWORD`.
3. Run the workflow again. Artifact `skyline-release` contains the signed `.aab` - upload that in Play Console.
   (Locally, set env vars KEYSTORE_FILE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD and run `./gradlew bundleRelease`.)
4. For each update raise `versionCode` in `app/build.gradle`.

## Play Console checklist
- One-time $25 developer account; enable Play App Signing.
- Store listing: icon `store/icon-512.png`, feature graphic `store/feature-graphic-1024x500.png`,
  at least 2 landscape phone screenshots, short + full description.
- Privacy policy URL (required), Data safety form (the app collects no data), content rating questionnaire.
- Make sure you may use every asset commercially. Check the licence of the Boeing 747-8i model you uploaded
  (and Boeing / airline trademarks and liveries). If unsure, switch the 747 back to the built-in one:
  delete `747-8i-model.js` and its `<script>` line in `index.html`.

## Controls
Left stick: pitch/roll | right slider: throttle | RUD buttons | GEAR, FLAPS, BRAKE, CAM, AP, pause.
Android Back = pause / resume / menu, and exits from the main menu.
